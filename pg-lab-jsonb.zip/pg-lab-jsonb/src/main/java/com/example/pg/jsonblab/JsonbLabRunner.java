package com.example.pg.jsonblab;

import org.postgresql.util.PGobject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.util.Random;

@Component
public class JsonbLabRunner implements CommandLineRunner {
    private final JdbcTemplate jdbc;
    @Value("${spring.datasource.username}") String user;

    public JsonbLabRunner(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Override public void run(String... args) throws Exception {
        String mode = arg(args, "--mode", null);
        if (mode == null) return;

        switch (mode) {
            case "setup" -> setup();
            case "insert" -> insert(Integer.parseInt(arg(args, "--n", "2000")));
            case "query" -> query(arg(args, "--sku", "A-1"));
            case "update" -> update(Long.parseLong(arg(args, "--id", "1")));
            case "remove" -> remove(Long.parseLong(arg(args, "--id", "1")), arg(args, "--field", "tags"));
            default -> System.out.println("Unknown mode: " + mode);
        }
    }

    private void setup() {
        jdbc.execute("CREATE SCHEMA IF NOT EXISTS app");
        jdbc.execute("CREATE TABLE IF NOT EXISTS app.events (" +
                "id BIGSERIAL PRIMARY KEY, " +
                "kind TEXT NOT NULL, " +
                "payload JSONB NOT NULL, " +
                "created_at timestamptz DEFAULT now())");
        jdbc.execute("CREATE INDEX IF NOT EXISTS idx_events_payload_gin ON app.events USING gin (payload jsonb_path_ops)");
        System.out.println("Setup complete (user=" + user + ").");
    }

    private void insert(int n) throws Exception {
        Random rnd = new Random(7);
        String sql = "INSERT INTO app.events(kind, payload) VALUES (?, ?)";
        for (int i = 0; i < n; i++) {
            PGobject json = new PGobject();
            json.setType("jsonb");
            String sku = "A-" + (1 + rnd.nextInt(9));
            int qty = 1 + rnd.nextInt(5);
            String payload = "{\"sku\":\"" + sku + "\",\"qty\":" + qty + ",\"tags\":[\"promo\",\"blue\"]}";
            json.setValue(payload);
            jdbc.update(sql, "order_created", json);
        }
        System.out.println("Inserted " + n + " rows.");
    }

    private void query(String sku) {
        System.out.println("Query by containment @> sku=" + sku);
        var rows = jdbc.queryForList("SELECT id FROM app.events WHERE payload @> ('{\"sku\":\"" + sku + "\"}')::jsonb LIMIT 10");
        System.out.println("Sample IDs: " + rows);

        System.out.println("EXPLAIN plan for containment query:");
        jdbc.query("EXPLAIN SELECT id FROM app.events WHERE payload @> ('{\"sku\":\"" + sku + "\"}')::jsonb",
                (ResultSet rs) -> { while (rs.next()) System.out.println(rs.getString(1)); });

        System.out.println("Field access ->> :");
        jdbc.query("SELECT id, payload->>'sku' AS sku FROM app.events WHERE kind = 'order_created' LIMIT 5",
                (ResultSet rs) -> { while (rs.next()) System.out.println(rs.getLong("id") + ":" + rs.getString("sku")); });

        System.out.println("Array contains ? operator:");
        jdbc.query("SELECT id FROM app.events WHERE payload->'tags' ? 'promo' LIMIT 5",
                (ResultSet rs) -> { while (rs.next()) System.out.println(rs.getLong(1)); });
    }

    private void update(long id) {
        int u1 = jdbc.update("UPDATE app.events SET payload = jsonb_set(payload, '{status}', '\"shipped\"', true) WHERE id = ?", id);
        int u2 = jdbc.update("UPDATE app.events SET payload = jsonb_set(payload, '{qty}', to_jsonb((payload->>'qty')::int + 1), true) WHERE id = ?", id);
        System.out.println("Updated rows: " + (u1 + u2));
    }

    private void remove(long id, String field) {
        int u = jdbc.update("UPDATE app.events SET payload = payload - ? WHERE id = ?", field, id);
        System.out.println("Removed field '" + field + "' from id=" + id + " (rows=" + u + ")");
    }

    private static String arg(String[] args, String key, String def) {
        for (String a : args) if (a.startsWith(key + "=")) return a.substring(key.length()+1);
        return def;
    }
}
