# Solution: JSONB Lab

This app demonstrates inserting, querying, indexing, and updating **JSONB** from Java.

## Build
```bash
mvn -q -DskipTests package
```

## Environment
```bash
export DB_HOST=localhost
export DB_PORT=5432
export DB_NAME=myapp
export DB_USER=app_user
export DB_PASSWORD=secret
```

## Run
- Setup schema/table/index:
```bash
java -jar target/pg-lab-jsonb-1.0.0.jar --mode=setup
```

- Insert sample JSONB events:
```bash
java -jar target/pg-lab-jsonb-1.0.0.jar --mode=insert --n=2000
```

- Query with JSONB operators (and print EXPLAIN plan):
```bash
java -jar target/pg-lab-jsonb-1.0.0.jar --mode=query --sku=A-1
```

- Update JSONB fields:
```bash
java -jar target/pg-lab-jsonb-1.0.0.jar --mode=update --id=1
```

- Remove fields:
```bash
java -jar target/pg-lab-jsonb-1.0.0.jar --mode=remove --id=1 --field=tags
```
