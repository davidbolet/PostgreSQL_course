package com.example.pg.connlab;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class JdbcMainRunner implements CommandLineRunner {
    private final JdbcBenchmarks bench;
    public JdbcMainRunner(JdbcBenchmarks bench) { this.bench = bench; }

    @Override public void run(String... args) throws Exception {
        String mode = null;
        for (String a : args) if (a.startsWith("--mode=")) mode = a.substring(7);
        if (mode == null) return; // do nothing by default

        switch (mode) {
            case "jdbc-setup" -> bench.setup();
            case "jdbc-insert-naive" -> bench.insertNaive(10_000);
            case "jdbc-insert-batch" -> bench.insertBatch(10_000);
            case "jdbc-fetch-naive" -> bench.fetchNaive();
            case "jdbc-fetch-stream" -> bench.fetchStream();
            default -> System.out.println("Unknown mode: " + mode);
        }
    }
}
