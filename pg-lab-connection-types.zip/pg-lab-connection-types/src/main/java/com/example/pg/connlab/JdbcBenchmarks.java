package com.example.pg.connlab;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.sql.*;
import java.time.Duration;
import java.time.Instant;
import java.util.Properties;
import java.util.Random;

@Component
public class JdbcBenchmarks {
    @Value("${spring.datasource.url}")
    String baseUrl;
    @Value("${spring.datasource.username}")
    String user;
    @Value("${spring.datasource.password}")
    String pass;
    @Value("${app.rewriteBatchedInserts:false}")
    boolean rewrite;
    @Value("${app.fetchSize:1000}")
    int fetchSize;

    private String urlWithRewrite(boolean enable) {
        String sep = baseUrl.contains("?") ? "&" : "?";
        return baseUrl + sep + "reWriteBatchedInserts=" + (enable ? "true" : "false");
    }

    public void setup() throws Exception {
        try (Connection con = DriverManager.getConnection(baseUrl, user, pass);
             Statement st = con.createStatement()) {
            st.executeUpdate("CREATE SCHEMA IF NOT EXISTS app");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS app.items (" +
                    "id BIGSERIAL PRIMARY KEY, " +
                    "sku TEXT NOT NULL, " +
                    "payload JSONB, " +
                    "created_at timestamptz DEFAULT now())");
            st.executeUpdate("CREATE INDEX IF NOT EXISTS idx_items_sku ON app.items(sku)");
            System.out.println("Setup complete.");
        }
    }

    public void insertNaive(int n) throws Exception {
        String sql = "INSERT INTO app.items (sku, payload) VALUES (?, to_jsonb(?::text))";
        Random rnd = new Random(42);
        Instant t0 = Instant.now();
        try (Connection con = DriverManager.getConnection(urlWithRewrite(false), user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            for (int i = 0; i < n; i++) {
                ps.setString(1, "SKU-" + (i+1));
                String payload = "{\"i\":" + i + ",\"r\":" + rnd.nextInt(1000) + "}";
                ps.setString(2, payload);
                ps.executeUpdate();
            }
        }
        System.out.println("Naive inserts: " + n + " rows in " + Duration.between(t0, Instant.now()).toMillis() + " ms");
    }

    public void insertBatch(int n) throws Exception {
        String sql = "INSERT INTO app.items (sku, payload) VALUES (?, to_jsonb(?::text))";
        Random rnd = new Random(42);
        Instant t0 = Instant.now();
        try (Connection con = DriverManager.getConnection(urlWithRewrite(rewrite), user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            for (int i = 0; i < n; i++) {
                ps.setString(1, "SKU-" + (i+1));
                String payload = "{\"i\":" + i + ",\"r\":" + rnd.nextInt(1000) + "}";
                ps.setString(2, payload);
                ps.addBatch();
                if (i % 1000 == 999) {
                    ps.executeBatch();
                }
            }
            ps.executeBatch();
        }
        System.out.println("Batched inserts (rewrite=" + rewrite + "): " + n + " rows in " + Duration.between(t0, Instant.now()).toMillis() + " ms");
    }

    public void fetchNaive() throws Exception {
        String sql = "SELECT id, sku, payload FROM app.items ORDER BY id";
        long rows = 0;
        Instant t0 = Instant.now();
        try (Connection con = DriverManager.getConnection(baseUrl, user, pass);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) rows++;
        }
        System.out.println("Naive fetch: " + rows + " rows in " + Duration.between(t0, Instant.now()).toMillis() + " ms");
    }

    public void fetchStream() throws Exception {
        String sql = "SELECT id, sku, payload FROM app.items ORDER BY id";
        long rows = 0;
        Instant t0 = Instant.now();
        try (Connection con = DriverManager.getConnection(baseUrl, user, pass)) {
            con.setAutoCommit(false); // enable cursor mode
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setFetchSize(fetchSize);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) rows++;
                }
            }
        }
        System.out.println("Stream fetch (fetchSize=" + fetchSize + "): " + rows + " rows in " + Duration.between(t0, Instant.now()).toMillis() + " ms");
    }
}
