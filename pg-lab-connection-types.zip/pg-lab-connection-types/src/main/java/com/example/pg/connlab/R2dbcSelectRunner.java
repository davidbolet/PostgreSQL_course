package com.example.pg.connlab;

import io.r2dbc.spi.ConnectionFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;

@Component
public class R2dbcSelectRunner implements CommandLineRunner {
    private final ConnectionFactory cf;
    public R2dbcSelectRunner(ConnectionFactory cf) { this.cf = cf; }

    @Override public void run(String... args) throws Exception {
        // activated only with --mode=r2dbc-select
        boolean run = false;
        for (String a : args) if (a.equals("--mode=r2dbc-select")) run = true;
        if (!run) return;

        System.out.println("R2DBC select: first 5 SKUs");
        Flux.usingWhen(cf.create(),
            conn -> Flux.from(conn.createStatement("SELECT sku FROM app.items ORDER BY id LIMIT 5").execute())
                        .flatMap(result -> result.map((row,meta) -> row.get("sku", String.class))),
            conn -> conn.close()
        ).doOnNext(System.out::println).blockLast();
    }
}
