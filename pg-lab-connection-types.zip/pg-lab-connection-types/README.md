# Solution: Connection Types & Patterns Lab

Run different modes with `--mode=<value>`:

- `jdbc-setup` — create schema/table/index.
- `jdbc-insert-naive` — 10k single-row inserts (no rewrite).
- `jdbc-insert-batch` — 10k batched inserts (enable rewrite via `REWRITE_BATCHED_INSERTS=true` env or URL param).
- `jdbc-fetch-naive` — naive fetch of 10k rows.
- `jdbc-fetch-stream` — cursor fetch with `setFetchSize`.
- `r2dbc-select` — simple R2DBC select demo.

## Build
```bash
mvn -q -DskipTests package
```

## Environment
```bash
export DB_HOST=localhost
export DB_PORT=5432
export DB_NAME=myapp
export DB_USER=app_user
export DB_PASSWORD=secret
```

## Create schema/table/index
```bash
java -jar target/pg-lab-connection-types-1.0.0.jar --mode=jdbc-setup
```

## Inserts
Naive:
```bash
java -jar target/pg-lab-connection-types-1.0.0.jar --mode=jdbc-insert-naive
```

Batch + rewrite (faster):
```bash
export REWRITE_BATCHED_INSERTS=true
java -jar target/pg-lab-connection-types-1.0.0.jar --mode=jdbc-insert-batch
```

## Fetch
Naive:
```bash
java -jar target/pg-lab-connection-types-1.0.0.jar --mode=jdbc-fetch-naive
```

Streamed:
```bash
export FETCH_SIZE=1000
java -jar target/pg-lab-connection-types-1.0.0.jar --mode=jdbc-fetch-stream
```

## R2DBC
```bash
java -jar target/pg-lab-connection-types-1.0.0.jar --mode=r2dbc-select
```
